public enum ScreenShakeType
{
	Small = 0,
	Big = 1,
	Long = 2,
	VeryStrong = 3
}
