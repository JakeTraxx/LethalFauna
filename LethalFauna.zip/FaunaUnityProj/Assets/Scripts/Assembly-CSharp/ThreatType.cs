using System;

[Serializable]
public enum ThreatType
{
	Player = 0,
	Projectile = 1,
	Bees = 2,
	EyelessDog = 3,
	ForestGiant = 4,
	Item = 5
}
