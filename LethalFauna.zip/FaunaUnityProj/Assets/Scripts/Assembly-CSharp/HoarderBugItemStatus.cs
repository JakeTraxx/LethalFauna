public enum HoarderBugItemStatus
{
	Any = -1,
	Owned = 0,
	Stolen = 1,
	Returned = 2
}
