using UnityEngine;

public class FloodWeather : MonoBehaviour
{
	public AudioSource waterAudio;

	private float floodLevelOffset;

	private float previousGlobalTime;

	private void OnEnable()
	{
	}

	private void OnDisable()
	{
	}

	private void OnGlobalTimeSync()
	{
	}

	private void Update()
	{
	}
}
