using DunGen;
using UnityEngine;

public class LevelGenerationManager : MonoBehaviour
{
	public RuntimeDungeon dungeonGenerator;

	private StartOfRound playersManager;

	private RoundManager roundManager;

	private void Awake()
	{
	}

	private void Update()
	{
	}
}
