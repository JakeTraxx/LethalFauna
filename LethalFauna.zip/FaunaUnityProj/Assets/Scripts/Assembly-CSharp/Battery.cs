using System;

[Serializable]
public class Battery
{
	public bool empty;

	public float charge;

	public Battery(bool isEmpty, float chargeNumber)
	{
	}
}
