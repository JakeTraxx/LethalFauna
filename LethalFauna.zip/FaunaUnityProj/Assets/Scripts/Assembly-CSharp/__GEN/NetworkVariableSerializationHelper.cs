using UnityEngine;

namespace __GEN
{
	internal class NetworkVariableSerializationHelper
	{
		
		internal static void InitializeSerialization()
		{
		}
	}
}
