using UnityEngine;

public class AnimationStopPoints : MonoBehaviour
{
	public bool canAnimationStop;

	public int animationPosition;

	public void SetAnimationStopPosition1()
	{
	}

	public void SetAnimationGo()
	{
	}

	public void SetAnimationStopPosition2()
	{
	}
}
