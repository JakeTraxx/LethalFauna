using System;

[Serializable]
public class DialogueSegment
{
	public string bodyText;

	public string speakerText;

	public float waitTime;
}
