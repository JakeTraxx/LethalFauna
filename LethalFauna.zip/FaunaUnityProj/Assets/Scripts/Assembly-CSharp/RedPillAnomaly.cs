public class RedPillAnomaly : Anomaly
{
}
