public enum CauseOfDeath
{
	Unknown = 0,
	Bludgeoning = 1,
	Gravity = 2,
	Blast = 3,
	Strangulation = 4,
	Suffocation = 5,
	Mauling = 6,
	Gunshots = 7,
	Crushing = 8,
	Drowning = 9,
	Abandoned = 10,
	Electrocution = 11,
	Kicking = 12
}
