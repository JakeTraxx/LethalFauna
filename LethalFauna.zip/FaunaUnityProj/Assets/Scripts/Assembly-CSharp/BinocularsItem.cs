public class BinocularsItem : GrabbableObject
{
}
