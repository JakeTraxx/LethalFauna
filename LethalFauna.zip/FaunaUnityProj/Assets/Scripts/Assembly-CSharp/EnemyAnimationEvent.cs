using UnityEngine;

public class EnemyAnimationEvent : MonoBehaviour
{
	public EnemyAI mainScript;

	public void PlayEventA()
	{
	}

	public void PlayEventB()
	{
	}
}
