using System.Collections.Generic;
using UnityEngine;

public class RandomMapObject : MonoBehaviour
{
	public List<GameObject> spawnablePrefabs;

	public bool randomizePosition;

	public float spawnRange;
}
