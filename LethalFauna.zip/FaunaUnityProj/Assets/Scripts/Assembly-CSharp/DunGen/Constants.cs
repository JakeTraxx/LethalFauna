namespace DunGen
{
	public static class Constants
	{
		public const string DefaultDungeonRootName = "Dungeon";
	}
}
