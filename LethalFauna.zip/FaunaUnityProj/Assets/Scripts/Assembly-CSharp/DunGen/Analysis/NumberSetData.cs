using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace DunGen.Analysis
{
	public sealed class NumberSetData
	{
		public float Min
		{
			[CompilerGenerated]
			get
			{
				return 0f;
			}
			[CompilerGenerated]
			private set
			{
			}
		}

		public float Max
		{
			[CompilerGenerated]
			get
			{
				return 0f;
			}
			[CompilerGenerated]
			private set
			{
			}
		}

		public float Average
		{
			[CompilerGenerated]
			get
			{
				return 0f;
			}
			[CompilerGenerated]
			private set
			{
			}
		}

		public float StandardDeviation
		{
			[CompilerGenerated]
			get
			{
				return 0f;
			}
			[CompilerGenerated]
			private set
			{
			}
		}

		public NumberSetData(IEnumerable<float> values)
		{
		}

		public override string ToString()
		{
			return null;
		}
	}
}
