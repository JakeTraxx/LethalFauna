using System.Runtime.CompilerServices;

namespace DunGen
{
	public struct DoorwayPair
	{
		public TileProxy PreviousTile
		{
			[CompilerGenerated]
			readonly get
			{
				return null;
			}
			[CompilerGenerated]
			private set
			{
			}
		}

		public DoorwayProxy PreviousDoorway
		{
			[CompilerGenerated]
			readonly get
			{
				return null;
			}
			[CompilerGenerated]
			private set
			{
			}
		}

		public TileProxy NextTemplate
		{
			[CompilerGenerated]
			readonly get
			{
				return null;
			}
			[CompilerGenerated]
			private set
			{
			}
		}

		public DoorwayProxy NextDoorway
		{
			[CompilerGenerated]
			readonly get
			{
				return null;
			}
			[CompilerGenerated]
			private set
			{
			}
		}

		public TileSet NextTileSet
		{
			[CompilerGenerated]
			readonly get
			{
				return null;
			}
			[CompilerGenerated]
			private set
			{
			}
		}

		public float TileWeight
		{
			[CompilerGenerated]
			readonly get
			{
				return 0f;
			}
			[CompilerGenerated]
			private set
			{
			}
		}

		public float DoorwayWeight
		{
			[CompilerGenerated]
			readonly get
			{
				return 0f;
			}
			[CompilerGenerated]
			private set
			{
			}
		}
	}
}
