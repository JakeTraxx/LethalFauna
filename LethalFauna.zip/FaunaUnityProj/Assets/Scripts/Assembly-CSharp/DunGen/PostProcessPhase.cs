namespace DunGen
{
	public enum PostProcessPhase
	{
		BeforeBuiltIn = 0,
		AfterBuiltIn = 1
	}
}
