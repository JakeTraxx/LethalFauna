using System.Runtime.CompilerServices;

namespace DunGen
{
	public sealed class DoorwayConnection
	{
		public Doorway A
		{
			[CompilerGenerated]
			get
			{
				return null;
			}
			[CompilerGenerated]
			private set
			{
			}
		}

		public Doorway B
		{
			[CompilerGenerated]
			get
			{
				return null;
			}
			[CompilerGenerated]
			private set
			{
			}
		}

		public DoorwayConnection(Doorway a, Doorway b)
		{
		}
	}
}
