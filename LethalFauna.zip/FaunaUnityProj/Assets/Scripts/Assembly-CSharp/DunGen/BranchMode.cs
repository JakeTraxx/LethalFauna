namespace DunGen
{
	public enum BranchMode
	{
		Local = 0,
		Global = 1
	}
}
