using System.Runtime.CompilerServices;

namespace DunGen
{
	public struct ProxyDoorwayConnection
	{
		public DoorwayProxy A
		{
			[CompilerGenerated]
			readonly get
			{
				return null;
			}
			[CompilerGenerated]
			private set
			{
			}
		}

		public DoorwayProxy B
		{
			[CompilerGenerated]
			readonly get
			{
				return null;
			}
			[CompilerGenerated]
			private set
			{
			}
		}
	}
}
