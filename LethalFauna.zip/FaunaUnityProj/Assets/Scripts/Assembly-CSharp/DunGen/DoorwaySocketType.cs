namespace DunGen
{
	public enum DoorwaySocketType
	{
		Default = 0,
		Large = 1,
		Vertical = 2
	}
}
