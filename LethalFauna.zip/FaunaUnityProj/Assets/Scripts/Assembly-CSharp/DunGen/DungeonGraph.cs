using System.Collections.Generic;

namespace DunGen
{
	public class DungeonGraph
	{
		public readonly List<DungeonGraphNode> Nodes;

		public readonly List<DungeonGraphConnection> Connections;

		public DungeonGraph(Dungeon dungeon)
		{
		}
	}
}
