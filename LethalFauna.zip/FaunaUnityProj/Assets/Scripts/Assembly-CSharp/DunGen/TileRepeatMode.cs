namespace DunGen
{
	public enum TileRepeatMode
	{
		Allow = 0,
		DisallowImmediate = 1,
		Disallow = 2
	}
}
