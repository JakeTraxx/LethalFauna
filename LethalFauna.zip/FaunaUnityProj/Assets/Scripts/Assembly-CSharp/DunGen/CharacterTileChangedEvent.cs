namespace DunGen
{
	public delegate void CharacterTileChangedEvent(DungenCharacter character, Tile previousTile, Tile newTile);
}
