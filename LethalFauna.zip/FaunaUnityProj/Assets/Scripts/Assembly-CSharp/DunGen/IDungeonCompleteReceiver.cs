namespace DunGen
{
	public interface IDungeonCompleteReceiver
	{
		void OnDungeonComplete(Dungeon dungeon);
	}
}
