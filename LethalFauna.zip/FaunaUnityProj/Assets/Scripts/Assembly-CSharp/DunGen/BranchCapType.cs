namespace DunGen
{
	public enum BranchCapType : byte
	{
		InsteadOf = 0,
		AsWellAs = 1
	}
}
