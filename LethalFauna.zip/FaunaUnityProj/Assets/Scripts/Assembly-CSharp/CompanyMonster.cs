public enum CompanyMonster
{
	GiantHand = 0,
	Tentacles = 1,
	Tongue = 2
}
