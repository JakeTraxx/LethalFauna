public class KeyItem : GrabbableObject
{
	public override void ItemActivate(bool used, bool buttonDown = true)
	{
	}
}
