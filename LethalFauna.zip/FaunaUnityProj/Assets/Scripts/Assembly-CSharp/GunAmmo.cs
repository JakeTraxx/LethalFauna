public class GunAmmo : GrabbableObject
{
	public int ammoType;
}
