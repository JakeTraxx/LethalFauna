using TMPro;
using UnityEngine;

public class SaveFileUISlot : MonoBehaviour
{
	public Animator buttonAnimator;

	public TextMeshProUGUI fileStatsText;

	public int fileNum;

	private string fileString;

	public TextMeshProUGUI fileNotCompatibleAlert;

	private void Awake()
	{
	}

	private void OnEnable()
	{
	}

	public void SetButtonColor()
	{
	}

	public void SetFileToThis()
	{
	}

	public void SetButtonColorForAllFileSlots()
	{
	}
}
