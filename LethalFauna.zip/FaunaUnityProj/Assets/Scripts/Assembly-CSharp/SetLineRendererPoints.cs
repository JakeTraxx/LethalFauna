using UnityEngine;

public class SetLineRendererPoints : MonoBehaviour
{
	private LineRenderer lineRenderer;

	public Transform anchor;

	public Transform target;

	private void Start()
	{
	}

	private void LateUpdate()
	{
	}
}
