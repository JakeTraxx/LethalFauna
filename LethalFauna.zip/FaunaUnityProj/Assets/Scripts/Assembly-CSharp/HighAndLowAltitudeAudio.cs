using UnityEngine;

public class HighAndLowAltitudeAudio : MonoBehaviour
{
	public AudioSource HighAudio;

	public AudioSource LowAudio;

	public float maxAltitude;

	public float minAltitude;

	private void Update()
	{
	}

	private void SetAudioVolumeBasedOnAltitude(float playerHeight)
	{
	}
}
