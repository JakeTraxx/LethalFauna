using UnityEngine;

public class CompanyMonsterCollisionDetect : MonoBehaviour
{
	public int monsterAnimationID;

	private void OnTriggerEnter(Collider other)
	{
	}
}
