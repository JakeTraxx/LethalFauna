using UnityEngine;

public class SelectUIForGamepad : MonoBehaviour
{
	public bool doOnStart;

	private void Start()
	{
	}

	private void OnEnable()
	{
	}

	private void OnDisable()
	{
	}
}
