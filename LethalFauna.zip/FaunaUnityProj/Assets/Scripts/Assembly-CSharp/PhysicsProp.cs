public class PhysicsProp : GrabbableObject
{
}
