using UnityEngine;

public class SpawnSyncedObject : MonoBehaviour
{
	public GameObject spawnPrefab;
}
