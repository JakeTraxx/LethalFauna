using UnityEngine;

public class RemoteProp : GrabbableObject
{
	public AudioSource remoteAudio;

	public override void ItemActivate(bool used, bool buttonDown = true)
	{
	}
}
