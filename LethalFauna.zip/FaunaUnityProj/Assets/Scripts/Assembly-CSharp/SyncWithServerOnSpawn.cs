using Unity.Netcode;

public class SyncWithServerOnSpawn : NetworkBehaviour
{
	public RoundManager roundManager;

	private bool hasSynced;

	private void Start()
	{
	}

	public void SyncWithServer()
	{
	}
}
