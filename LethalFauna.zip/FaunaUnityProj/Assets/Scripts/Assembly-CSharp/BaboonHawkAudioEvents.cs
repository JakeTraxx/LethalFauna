using UnityEngine;

public class BaboonHawkAudioEvents : MonoBehaviour
{
	public AudioSource audioToPlay;

	public AudioClip[] randomClips;

	public Animator thisAnimator;

	private float timeLastAudioPlayed;

	public ParticleSystem particle;

	public void PlayParticleWithChildren()
	{
	}

	public void PlayAudio1RandomClipWithMinSpeedCondition()
	{
	}
}
