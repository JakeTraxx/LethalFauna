using UnityEngine;

public class ShakeRigidbodies : MonoBehaviour
{
	public Rigidbody[] rigidBodies;

	public float shakeTimer;

	public float shakeIntensity;

	private bool shaking;

	private void Update()
	{
	}

	private void FixedUpdate()
	{
	}
}
