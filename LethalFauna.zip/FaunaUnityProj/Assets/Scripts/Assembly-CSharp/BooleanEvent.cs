using System;
using UnityEngine.Events;

[Serializable]
public class BooleanEvent : UnityEvent<bool>
{
	public BooleanEvent()
	{
	}
}
