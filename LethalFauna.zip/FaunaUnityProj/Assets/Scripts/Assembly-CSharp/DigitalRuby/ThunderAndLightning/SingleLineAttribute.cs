using System.Runtime.CompilerServices;
using UnityEngine;

namespace DigitalRuby.ThunderAndLightning
{
	public class SingleLineAttribute : PropertyAttribute
	{
		public string Tooltip
		{
			[CompilerGenerated]
			get
			{
				return null;
			}
			[CompilerGenerated]
			private set
			{
			}
		}

		public SingleLineAttribute(string tooltip)
		{
		}
	}
}
