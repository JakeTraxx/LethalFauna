namespace DigitalRuby.ThunderAndLightning
{
	public enum LightningBoltQualitySetting
	{
		UseScript = 0,
		LimitToQualitySetting = 1
	}
}
