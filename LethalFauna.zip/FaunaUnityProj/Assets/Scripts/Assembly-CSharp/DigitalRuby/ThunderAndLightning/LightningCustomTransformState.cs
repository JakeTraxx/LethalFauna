namespace DigitalRuby.ThunderAndLightning
{
	public enum LightningCustomTransformState
	{
		Started = 0,
		Executing = 1,
		Ended = 2
	}
}
