using UnityEngine;

namespace DigitalRuby.ThunderAndLightning
{
	public class LightningGizmoScript : MonoBehaviour
	{
	}
}
