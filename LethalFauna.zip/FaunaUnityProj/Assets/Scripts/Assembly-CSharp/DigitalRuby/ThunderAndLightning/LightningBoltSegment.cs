using UnityEngine;

namespace DigitalRuby.ThunderAndLightning
{
	public struct LightningBoltSegment
	{
		public Vector3 Start;

		public Vector3 End;

		public override string ToString()
		{
			return null;
		}
	}
}
