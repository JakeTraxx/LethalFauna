using System.Runtime.CompilerServices;

namespace DigitalRuby.ThunderAndLightning
{
	public class LightningQualityMaximum
	{
		public int MaximumGenerations
		{
			[CompilerGenerated]
			get
			{
				return 0;
			}
			[CompilerGenerated]
			set
			{
			}
		}

		public float MaximumLightPercent
		{
			[CompilerGenerated]
			get
			{
				return 0f;
			}
			[CompilerGenerated]
			set
			{
			}
		}

		public float MaximumShadowPercent
		{
			[CompilerGenerated]
			get
			{
				return 0f;
			}
			[CompilerGenerated]
			set
			{
			}
		}
	}
}
