namespace DigitalRuby.ThunderAndLightning
{
	public enum CameraMode
	{
		Auto = 0,
		Perspective = 1,
		OrthographicXY = 2,
		OrthographicXZ = 3,
		Unknown = 4
	}
}
