using UnityEngine.Events;

public class SimpleEvent : UnityEvent
{
}
