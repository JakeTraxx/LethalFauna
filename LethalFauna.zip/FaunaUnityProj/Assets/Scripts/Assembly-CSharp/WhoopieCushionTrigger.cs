using UnityEngine;

public class WhoopieCushionTrigger : MonoBehaviour
{
	public WhoopieCushionItem itemScript;

	private void OnTriggerEnter(Collider other)
	{
	}
}
